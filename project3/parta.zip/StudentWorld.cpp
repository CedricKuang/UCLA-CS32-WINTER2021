#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <sstream>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    m_ghostracer = nullptr;
    soul_saved = 0;
    bonus_score = 5000;
    level_end = false;
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

int StudentWorld::init()
{
    GhostRacer* ghostracer = new GhostRacer(this);
    m_ghostracer = ghostracer;
    int N = VIEW_HEIGHT / SPRITE_HEIGHT;
    int M = VIEW_HEIGHT / (4 * SPRITE_HEIGHT);
    int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;
    for (int j = 0; j < N; j++)
    {
        BorderLine* left_yellow_borderline = new BorderLine(IID_YELLOW_BORDER_LINE, LEFT_EDGE, j * SPRITE_HEIGHT, this);
        BorderLine* right_yellow_borderline = new BorderLine(IID_YELLOW_BORDER_LINE, RIGHT_EDGE, j * SPRITE_HEIGHT, this);
        m_actor.push_back(left_yellow_borderline);
        m_actor.push_back(right_yellow_borderline);
    }
    for (int j = 0; j < M; j++)
    {
        BorderLine* left_white_borderline = new BorderLine(IID_WHITE_BORDER_LINE, LEFT_EDGE + ROAD_WIDTH / 3, j * 4 * SPRITE_HEIGHT, this);
        BorderLine* right_white_borderline = new BorderLine(IID_WHITE_BORDER_LINE, RIGHT_EDGE - ROAD_WIDTH / 3, j * 4 * SPRITE_HEIGHT, this);
        m_actor.push_back(left_white_borderline);
        m_actor.push_back(right_white_borderline);
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    vector<Actor*>::iterator it = m_actor.begin();
    m_ghostracer->doSomething();
    for (; it != m_actor.end(); it++)
    {
        if ((*it)->is_alive())
            (*it)->doSomething();
        
        if (!m_ghostracer->is_alive())
        {
            decLives();
            return GWSTATUS_PLAYER_DIED;
        }
        else if (get_soul_saved() >= getLevel() * 2 + 5)
        {
            increaseScore(get_bonus_score());
            return GWSTATUS_FINISHED_LEVEL;
        }
    }

    it = m_actor.begin();
    while (it != m_actor.end())
    {
        if (!(*it)->is_alive())
        {
            delete* it;
            m_actor.erase(it);
            it = m_actor.begin();
        }
        else
            it++;
    }

    add_borderline();
    //add_human_ped();
    //add_zombie_ped();
    //add_zombie_cab();
    //to be added more actors;
    ostringstream oss;
    string text;
    oss << "Score: " << getScore() << "  " << "Lvl: " << getLevel() << "  " << "Souls2Save: " << getLevel() * 2 + 5 - get_soul_saved()
        << "  " << "Lives: " << getLives() << "  " << "Health: " << m_ghostracer->get_hit_point() << "  " << "Spray: " << m_ghostracer->get_holy_water_spray()
        << "  " << "Bonus: " << get_bonus_score();
    text = oss.str();
    setGameStatText(text);
    if (get_bonus_score() > 0)
        set_bonus_score(get_bonus_score() - 1);
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    vector<Actor*>::iterator it = m_actor.begin();
    while (it != m_actor.end())
    {
        delete* it;
        m_actor.erase(it);
        it = m_actor.begin();
    }
    delete m_ghostracer;
}

GhostRacer* StudentWorld::getghostracer() const
{
    return m_ghostracer;
}

int StudentWorld::get_soul_saved() const
{
    return soul_saved;
}

void StudentWorld::save_a_soul()
{
    soul_saved++;
}

int StudentWorld::get_bonus_score() const
{
    return bonus_score;
}

void StudentWorld::set_bonus_score(int score)
{
    bonus_score = score;
}

vector<Actor*> StudentWorld::get_m_actor()
{
    return m_actor;
}

void StudentWorld::add_borderline()
{
    int new_border_y = VIEW_HEIGHT - SPRITE_HEIGHT;
    vector<Actor*>::iterator it = m_actor.end();
    it--;
    while (it != m_actor.begin())
    {
        if ((*it)->get_hit_point() == -1 && ((*it)->getX() == ROAD_CENTER - ROAD_WIDTH / 2 + ROAD_WIDTH / 3 || (*it)->getX() == ROAD_CENTER + ROAD_WIDTH / 2 - ROAD_WIDTH / 3))
            break;
        it--;
    }
    int delta_y = new_border_y - (*it)->getY();
    if (delta_y >= SPRITE_HEIGHT)
    {
        BorderLine* left_yellow_borderline = new BorderLine(IID_YELLOW_BORDER_LINE, ROAD_CENTER - ROAD_WIDTH / 2, new_border_y, this);
        BorderLine* right_yellow_borderline = new BorderLine(IID_YELLOW_BORDER_LINE, ROAD_CENTER + ROAD_WIDTH / 2, new_border_y, this);
        m_actor.push_back(left_yellow_borderline);
        m_actor.push_back(right_yellow_borderline);
    }
    if (delta_y >= 4 * SPRITE_HEIGHT)
    {
        BorderLine* left_white_borderline = new BorderLine(IID_WHITE_BORDER_LINE, ROAD_CENTER - ROAD_WIDTH / 2 + ROAD_WIDTH / 3, new_border_y, this);
        BorderLine* right_white_borderline = new BorderLine(IID_WHITE_BORDER_LINE, ROAD_CENTER + ROAD_WIDTH / 2 - ROAD_WIDTH / 3, new_border_y, this);
        m_actor.push_back(left_white_borderline);
        m_actor.push_back(right_white_borderline);
    }
}
/*
void StudentWorld::add_human_ped()
{
    int ChanceHumanPed = max(200 - getLevel() * 10, 30);
    int rand_int = randInt(0, ChanceHumanPed - 1);
    if (rand_int == 0)
    {
        double x_cor = randInt(0, VIEW_WIDTH);
        double y_cor = VIEW_HEIGHT;
        HumanPedestrian* newhuman = new HumanPedestrian(x_cor, y_cor, this);
        m_actor.push_back(newhuman);
    }
}

void StudentWorld::add_zombie_ped()
{
    int ChanceZombiePed = max(100 - getLevel() * 10, 20);
    int rand_int = randInt(0, ChanceZombiePed - 1);
    if (rand_int == 0)
    {
        double x_cor = randInt(0, VIEW_WIDTH);
        double y_cor = VIEW_HEIGHT;
        ZombiePedestrian* newzombie = new ZombiePedestrian(x_cor, y_cor, this);
        m_actor.push_back(newzombie);
    }
}

void StudentWorld::add_zombie_cab()
{
    int ChanceVehicle = max(100 - getLevel() * 10, 20);
    int rand_int = randInt(0, ChanceVehicle - 1);
    if (rand_int == 0)
    {
        vector<Actor*>::iterator it = m_actor.begin();
        int cur_lane = randInt(1, 3);
        for (int i = 1; i <= 3; i++)
        {
            int x_cor = get_lane_x_coordinate(cur_lane);
            while (it != m_actor.end())
            {
                if ((*it)->get_cawa() && (*it)->in_which_line() == cur_lane && (*it)->getY() <= VIEW_HEIGHT / 3)
                    break;
                else if (m_ghostracer->in_which_line() == cur_lane)
                    break;
                it++;
            }
            if (it == m_actor.end())
            {
                ZombieCab* new_cab = new ZombieCab(x_cor, SPRITE_HEIGHT / 2, m_ghostracer->get_v_speed() + randInt(2, 4), this);
                m_actor.push_back(new_cab);
                break;
            }

            it = m_actor.begin();
            while (it != m_actor.end())
            {
                if ((*it)->get_cawa() && (*it)->in_which_line() == cur_lane && (*it)->getY() >= VIEW_HEIGHT * 2 / 3)
                    break;
                it++;
            }
            if (it == m_actor.end())
            {
                ZombieCab* new_cab = new ZombieCab(x_cor, VIEW_HEIGHT - SPRITE_HEIGHT / 2, m_ghostracer->get_v_speed() - randInt(2, 4), this);
                m_actor.push_back(new_cab);
                break;
            }

            if (cur_lane == 3)
                cur_lane = 1;
            else
                cur_lane++;
        }
    }
}

double StudentWorld::get_lane_x_coordinate(int n) const
{
    if (n == 1)
        return ROAD_CENTER - ROAD_WIDTH / 3;
    else if (n == 2)
        return ROAD_CENTER;
    else if (n == 3)
        return ROAD_CENTER + ROAD_WIDTH / 3;
    else
        return 0;
}*/