#include "Actor.h"
#include "StudentWorld.h"
#include <vector>

//implementation of Actor base class derived from GraphObject class
Actor::Actor(StudentWorld* studentworld, bool al, int v_speed, int h_speed, int h_point, bool cawa,
	int ID, double start_x, double start_y, int dir, double size, unsigned int depth)
	: GraphObject(ID, start_x, start_y, dir, size, depth)
{
	alive = al;
	vertical_speed = v_speed;
	horizontal_speed = h_speed;
	hit_point = h_point;
	collision_avoidance_worthy_actor = cawa;
	m_studentworld = studentworld;
}

bool Actor::is_alive() const
{
	return alive;
}

void Actor::set_alive(bool al)
{
	alive = al;
}

int Actor::get_v_speed() const
{
	return vertical_speed;
}

void Actor::set_v_speed(int v_speed)
{
	vertical_speed = v_speed;
}

int Actor::get_h_speed() const
{
	return horizontal_speed;
}

void Actor::set_h_speed(int h_speed)
{
	horizontal_speed = h_speed;
}

int Actor::get_hit_point() const
{
	return hit_point;
}

void Actor::set_hit_point(int hitpoint)
{
	hit_point = hitpoint;
}

bool Actor::get_cawa() const
{
	return collision_avoidance_worthy_actor;
}

StudentWorld* Actor::get_studentworld() const
{
	return m_studentworld;
}

bool Actor::is_overlap(Actor* ac) const
{
	double delta_x = fabs(getX() - ac->getX());
	double delta_y = fabs(getY() - ac->getY());
	double radius_sum = getRadius() + ac->getRadius();
	if (delta_x < radius_sum * 0.25 && delta_y < radius_sum * 0.6)
		return true;
	else
		return false;
}

int Actor::in_which_line() const
{
	if (getX() >= ROAD_CENTER - ROAD_WIDTH / 2 && getX() < ROAD_CENTER - ROAD_WIDTH / 2 + ROAD_WIDTH / 3)
		return 1;
	else if (getX() < ROAD_CENTER + ROAD_WIDTH / 2 - ROAD_WIDTH / 3 && getX() >= ROAD_CENTER - ROAD_WIDTH / 2 + ROAD_WIDTH / 3)
		return 2;
	else if (getX() >= ROAD_CENTER + ROAD_WIDTH / 2 - ROAD_WIDTH / 3 && getX() < ROAD_CENTER + ROAD_WIDTH / 2)
		return 3;
	else
		return 0;
}

//implementation of GhostRacer derived from Actor
GhostRacer::GhostRacer(StudentWorld* studentworld, int hws, bool al, int v_speed, int h_speed, int h_point, bool cawa,
	int ID, double start_x, double start_y, int dir, double size, unsigned int depth)
	: Actor(studentworld, al, v_speed, h_speed, h_point, cawa, ID, start_x, start_y, dir, size, depth)
{
	holy_water_spray = hws;
}

void GhostRacer::doSomething()
{
	if (get_hit_point() <= 0)
		return;

	int ch;
	if (getX() <= ROAD_CENTER - ROAD_WIDTH / 2)
	{
		if (getDirection() > 90)
		{
			set_hit_point(get_hit_point() - 10);
			if (check_hit_point())
				return;
		}
		setDirection(82);
		get_studentworld()->playSound(SOUND_VEHICLE_CRASH);
	}
	else if (getX() >= ROAD_CENTER + ROAD_WIDTH / 2)
	{
		if (getDirection() < 90)
		{
			set_hit_point(get_hit_point() - 10);
			if (check_hit_point())
				return;
		}
		setDirection(98);
		get_studentworld()->playSound(SOUND_VEHICLE_CRASH);
	}
	else if (get_studentworld()->getKey(ch))
	{
		switch (ch)
		{
		case KEY_PRESS_SPACE:
			if (get_holy_water_spray() >= 1)
			{
				//add holy water
				get_studentworld()->playSound(SOUND_PLAYER_SPRAY);
				set_holy_water_spray(get_holy_water_spray() - 1);
			}
			break;
		case KEY_PRESS_LEFT:
			if (getDirection() < 114)
				setDirection(getDirection() + 8);
			break;
		case KEY_PRESS_RIGHT:
			if (getDirection() > 66)
				setDirection(getDirection() - 8);
			break;
		case KEY_PRESS_UP:
			if (get_v_speed() < 5)
				set_v_speed(get_v_speed() + 1);
			break;
		case KEY_PRESS_DOWN:
			if (get_v_speed() > -1)
				set_v_speed(get_v_speed() - 1);
			break;
		}
	}
	m_move();
}

void GhostRacer::m_move()
{
	double max_shift_per_tick = 4.0;
	int direction = getDirection();
	double delta_x;
	delta_x = cos((direction / 180.0) * 3.1415926) * max_shift_per_tick;
	double cur_x = getX();
	double cur_y = getY();
	moveTo(cur_x + delta_x, cur_y);
}

void GhostRacer::set_holy_water_spray(int hws)
{
	holy_water_spray = hws;
}

int GhostRacer::get_holy_water_spray() const
{
	return holy_water_spray;
}

bool GhostRacer::check_hit_point()
{
	if (get_hit_point() <= 0)
	{
		set_alive(false);
		get_studentworld()->playSound(SOUND_PLAYER_DIE);
		return true;
	}
	else
		return false;
}

//implementation of Borderline derived from Actor
BorderLine::BorderLine(int ID, double start_x, double start_y, StudentWorld* studentworld, bool al, int v_speed, int h_speed, int h_point,
	bool cawa, int dir, double size, unsigned int depth)
	: Actor(studentworld, al, v_speed, h_speed, h_point, cawa, ID, start_x, start_y, dir, size, depth)
{ }

void BorderLine::doSomething()
{
	int vert_speed = get_v_speed() - get_studentworld()->getghostracer()->get_v_speed();
	int horiz_speed = get_h_speed();
	int new_y = getY() + vert_speed;
	int new_x = getX() + horiz_speed;
	moveTo(new_x, new_y);
	if (getX() < 0 || getY() < 0 || getX() > VIEW_WIDTH || getY() > VIEW_HEIGHT)
		set_alive(false);
}
/*
//implementation of MovingWalkingActor (for zombie and pedestrian)
MovingWalkingActor::MovingWalkingActor(double start_x, double start_y, double size, int ID, StudentWorld* studentworld, double mpd, bool al, int v_speed, int h_speed,
	int h_point, bool cawa, int dir, unsigned int depth)
	: Actor(studentworld, al, v_speed, h_speed, h_point, cawa, ID, start_x, start_y, dir, size, depth)
{
	movement_plan_distance = mpd;
}

void MovingWalkingActor::m_move()
{
	double vert_speed = get_v_speed() - get_studentworld()->getghostracer()->get_v_speed();
	double horiz_speed = get_h_speed();
	double new_y = getY() + vert_speed;
	double new_x = getX() + horiz_speed;
	moveTo(new_x, new_y);
	if (getX() < 0 || getY() < 0 || getX() > VIEW_WIDTH || getY() > VIEW_HEIGHT)
		set_alive(false);
}

void MovingWalkingActor::set_mpd(int n)
{
	movement_plan_distance = randInt(4, 32);
	if (n == 3)
	{
		int h_speed = randInt(-3, 3);
		while (h_speed == 0)
			h_speed = randInt(-3, 3);
		set_h_speed(h_speed);
		int direction = (get_h_speed() < 0) ? 180 : 0;
		setDirection(direction);
	}
	else
		set_v_speed(randInt(-2, 2));
}

double MovingWalkingActor::get_mpd() const
{
	return movement_plan_distance;
}

bool MovingWalkingActor::dec_mpd()
{
	if (movement_plan_distance > 0)
	{
		movement_plan_distance--;
		return true;
	}
	else
		return false;
}

//implementation of HumanPedestrian derived from MovingWalkingActor
HumanPedestrian::HumanPedestrian(double start_x, double start_y, StudentWorld* studentworld, double size, int ID, double mpd, bool al, int v_speed, int h_speed,
	int h_point, bool cawa, int dir, unsigned int depth)
	: MovingWalkingActor(start_x, start_y, size, ID, studentworld)
{}

void HumanPedestrian::doSomething()
{
	if (!is_alive())
		return;
	if (is_overlap(get_studentworld()->getghostracer()))
	{
		get_studentworld()->getghostracer()->set_alive(false);
		return;
	}
	MovingWalkingActor::m_move();
	if (!is_alive())
		return;
	if (MovingWalkingActor::dec_mpd())
		return;
	else
		MovingWalkingActor::set_mpd(3);
}

//implementation of ZombiePedestrian derived from MovingWalkingActor
ZombiePedestrian::ZombiePedestrian(double start_x, double start_y, StudentWorld* studentworld, int t, double size, int ID, double mpd, bool al, int v_speed, int h_speed,
	int h_point, bool cawa, int dir, unsigned int depth)
	: MovingWalkingActor(start_x, start_y, size, ID, studentworld)
{
	ticks = t;
}

void ZombiePedestrian::set_ticks(int tick)
{
	ticks = tick;
}

int ZombiePedestrian::get_ticks() const
{
	return ticks;
}

void ZombiePedestrian::doSomething()
{
	if (!is_alive())
		return;

	if (is_overlap(get_studentworld()->getghostracer()))
	{
		get_studentworld()->getghostracer()->set_hit_point(get_studentworld()->getghostracer()->get_hit_point() - 5);
		if (get_studentworld()->getghostracer()->check_hit_point())
			return;
		set_hit_point(get_hit_point() - 2);
		if (get_hit_point() <= 0)
		{
			set_alive(false);
			get_studentworld()->playSound(SOUND_PED_DIE);
			get_studentworld()->increaseScore(150);
		}
		else
			get_studentworld()->playSound(SOUND_PED_HURT);
		return;
	}

	double delta_x = getX() - get_studentworld()->getghostracer()->getX();
	if (delta_x <= 30.0 && delta_x >= -30.0 && getY() > get_studentworld()->getghostracer()->getY())
	{
		setDirection(270);
		if (delta_x <= 30.0 && delta_x > 0.0)
			set_h_speed(-1);
		else if (delta_x >= -30.0 && delta_x < 0.0)
			set_h_speed(1);
		else
			set_h_speed(0);
		set_ticks(get_ticks() - 1);
		if (ticks <= 0)
		{
			get_studentworld()->playSound(SOUND_ZOMBIE_ATTACK);
			set_ticks(20);
		}
	}

	MovingWalkingActor::m_move();
	if (!is_alive())
		return;
	if (MovingWalkingActor::dec_mpd())
		return;
	else
		MovingWalkingActor::set_mpd(3);
}

//implementation of ZombieCab derived from WalkingMovingActor
ZombieCab::ZombieCab(double start_x, double start_y, int v_speed, StudentWorld* studentworld, int ID, bool d_g, double size, double mpd, bool al, int h_speed,
	int h_point, bool cawa, int dir, unsigned int depth)
	: MovingWalkingActor(start_x, start_y, size, ID, studentworld, mpd, al, v_speed, h_speed, h_point, cawa, dir, depth)
{
	damaged_ghostracer = d_g;
}

void ZombieCab::set_damaged_ghostracer(bool d_g)
{
	damaged_ghostracer = d_g;
}

bool ZombieCab::get_damaged_ghostracer() const
{
	return damaged_ghostracer;
}

void ZombieCab::doSomething()
{
	if (!is_alive())
		return;

	if (is_overlap(get_studentworld()->getghostracer()) && !get_damaged_ghostracer())
	{
		get_studentworld()->playSound(SOUND_VEHICLE_CRASH);
		get_studentworld()->getghostracer()->set_hit_point(get_studentworld()->getghostracer()->get_hit_point() - 20);
		if (get_studentworld()->getghostracer()->check_hit_point())
			return;
		if (getX() <= get_studentworld()->getghostracer()->getX())
		{
			set_h_speed(-5);
			setDirection(120 + randInt(0, 19));
		}
		if (getX() > get_studentworld()->getghostracer()->getX())
		{
			set_h_speed(5);
			setDirection(60 - randInt(0, 19));
		}
		set_damaged_ghostracer(true);
	}

	MovingWalkingActor::m_move();
	if (!is_alive())
		return;

	std::vector<Actor*> temp = get_studentworld()->get_m_actor();
	std::vector<Actor*>::iterator it = temp.begin();
	if (get_v_speed() > get_studentworld()->getghostracer()->get_v_speed())
	{
		while (it != temp.end())
		{
			if ((*it)->get_cawa() && (*it)->getY() > getY() && (*it)->in_which_line() == in_which_line() && (*it)->getY() - getY() < 96)
			{
				set_v_speed(get_v_speed() - 0.5);
				return;
			}
			it++;
		}
	}
	else if (get_v_speed() <= get_studentworld()->getghostracer()->get_v_speed())
	{
		while (it != temp.end())
		{
			if ((*it)->get_cawa() && (*it)->getY() < getY() && (*it)->in_which_line() == in_which_line() && getY() - (*it)->getY() < 96)
			{
				set_v_speed(get_v_speed() + 0.5);
				return;
			}
			it++;
		}
	}

	if (MovingWalkingActor::dec_mpd())
		return;
	else
		MovingWalkingActor::set_mpd(2);
}*/
